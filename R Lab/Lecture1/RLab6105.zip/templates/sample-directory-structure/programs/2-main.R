source("header.R")

dfz <- readRDS("dfz.rds")









